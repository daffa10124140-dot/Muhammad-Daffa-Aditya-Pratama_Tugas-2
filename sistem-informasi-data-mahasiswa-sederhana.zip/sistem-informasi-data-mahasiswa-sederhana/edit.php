<?php
require "fungsi.php";
require "koneksi.php";

if (!isset($_GET["id"]) || !ctype_digit($_GET["id"])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET["id"];
$sql = $koneksi->prepare("SELECT * FROM mahasiswa WHERE id = ?");
$sql->execute([$id]);
$mhs = $sql->fetch(PDO::FETCH_ASSOC);

if (!$mhs) {
    header("Location: index.php");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nim = trim($_POST["nim"]);
    $nama = trim($_POST["nama"]);
    $email = trim($_POST["email"]);
    $jenis_kelamin = isset($_POST["jenis_kelamin"]) ? $_POST["jenis_kelamin"] : "";
    $prodi = trim($_POST["prodi"]);

    if ($nim == "" || $nama == "" || $email == "" || $jenis_kelamin == "" || $prodi == "") {
        $error = "Semua kolom wajib diisi";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid";
    } else {
        try {
            $sql = $koneksi->prepare(
                "UPDATE mahasiswa SET nim = ?, nama = ?, email = ?, jenis_kelamin = ?, prodi = ? WHERE id = ?"
            );
            $sql->execute([$nim, $nama, $email, $jenis_kelamin, $prodi, $id]);
            header("Location: index.php");
            exit;
        } catch (PDOException $e) {
            $error = "Data gagal diubah. Pastikan NIM tidak dipakai mahasiswa lain";
        }
    }
}

$nilai = [
    "nim" => isset($nim) ? $nim : $mhs["nim"],
    "nama" => isset($nama) ? $nama : $mhs["nama"],
    "email" => isset($email) ? $email : $mhs["email"],
    "jenis_kelamin" => isset($jenis_kelamin) ? $jenis_kelamin : $mhs["jenis_kelamin"],
    "prodi" => isset($prodi) ? $prodi : $mhs["prodi"]
];
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f1efe8">
    <title>Edit Mahasiswa — Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main class="container form-panel">
        <div class="form-topline">
            <div class="brand-lockup">
                <span class="brand-mark" aria-hidden="true">M</span>
                <div>
                    <p class="eyebrow">Student records</p>
                    <p class="subtitle">Administrasi data</p>
                </div>
            </div>
            <a class="back-link" href="index.php">← Kembali ke daftar</a>
        </div>
        <div class="form-intro">
            <p class="eyebrow">Perbarui catatan</p>
            <h1>Edit Mahasiswa</h1>
            <p class="subtitle">Periksa kembali informasi di bawah sebelum menyimpan perubahan</p>
        </div>
        <?php if ($error != "") { ?>
            <p class="error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php } ?>
        <form method="POST" action="edit.php?id=<?php echo $id; ?>" class="form-layout">
            <div class="form-grid">
                <div class="field">
                    <label for="nim">NIM</label>
                    <input id="nim" type="text" name="nim" required
                        value="<?php echo htmlspecialchars($nilai["nim"]); ?>">
                </div>
                <div class="field">
                    <label for="nama">Nama Lengkap</label>
                    <input id="nama" type="text" name="nama" required
                        value="<?php echo htmlspecialchars($nilai["nama"]); ?>">
                </div>
                <div class="field full">
                    <label for="email">Email</label>
                    <input id="email" type="email" name="email" required
                        value="<?php echo htmlspecialchars($nilai["email"]); ?>">
                </div>
                <div class="field">
                    <label for="jenis_kelamin">Jenis Kelamin</label>
                    <select id="jenis_kelamin" name="jenis_kelamin" required>
                        <option value="Laki-laki" <?php echo $nilai["jenis_kelamin"] == "Laki-laki" ? "selected" : ""; ?>>
                            Laki-laki</option>
                        <option value="Perempuan" <?php echo $nilai["jenis_kelamin"] == "Perempuan" ? "selected" : ""; ?>>
                            Perempuan</option>
                    </select>
                </div>
                <div class="field">
                    <label for="prodi">Program Studi</label>
                    <select id="prodi" name="prodi" required>
                        <option value="Teknik Informatika" <?php echo $nilai["prodi"] == "Teknik Informatika" ? "selected" : ""; ?>>Teknik Informatika</option>
                        <option value="Sistem Informasi" <?php echo $nilai["prodi"] == "Sistem Informasi" ? "selected" : ""; ?>>Sistem Informasi</option>
                        <option value="Manajemen Informatika" <?php echo $nilai["prodi"] == "Manajemen Informatika" ? "selected" : ""; ?>>Manajemen Informatika</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit">Simpan perubahan</button>
                <a class="cancel-link" href="index.php">Batalkan</a>
            </div>
        </form>
    </main>
</body>

</html>