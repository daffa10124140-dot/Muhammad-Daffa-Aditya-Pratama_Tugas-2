<?php
require "fungsi.php";
require "koneksi.php";

$kata = isset($_GET["cari"]) ? trim($_GET["cari"]) : "";

if ($kata != "") {
    $sql = $koneksi->prepare(
        "SELECT * FROM mahasiswa WHERE nim LIKE ? OR nama LIKE ? ORDER BY id DESC"
    );
    $sql->execute(["%$kata%", "%$kata%"]);
} else {
    $sql = $koneksi->query("SELECT * FROM mahasiswa ORDER BY id DESC");
}
$data = $sql->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="<?php echo $bahasa == 'en' ? 'en' : 'id'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f1efe8">
    <title><?php echo teks("Data Mahasiswa", "Student Data"); ?> — Administrasi</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main class="container dashboard">
        <header class="top">
            <div class="brand-lockup">
                <span class="brand-mark" aria-hidden="true">M</span>
                <div>
                    <p class="eyebrow">Student records / Administration</p>
                    <h1><?php echo teks("Sistem Data Mahasiswa", "Student Data System"); ?></h1>
                    <p class="subtitle">
                        <?php echo teks("Ruang kerja untuk mengelola informasi mahasiswa", "A workspace for managing student information"); ?>
                    </p>
                </div>
            </div>
            <div class="account-area">
                <p class="eyebrow"><?php echo teks("Sesi aktif", "Active session"); ?></p>
                <strong><?php echo htmlspecialchars($_SESSION["username"]); ?></strong>
                <nav class="utility-links" aria-label="Pengaturan akun dan bahasa">
                    <a href="bahasa.php?lang=id&amp;kembali=index.php">Indonesia</a>
                    <span aria-hidden="true">/</span>
                    <a href="bahasa.php?lang=en&amp;kembali=index.php">English</a>
                    <span aria-hidden="true">·</span>
                    <a class="logout-link" href="logout.php"><?php echo teks("Keluar", "Logout"); ?></a>
                </nav>
            </div>
        </header>

        <section class="workspace-head">
            <div>
                <p class="eyebrow"><?php echo teks("Ringkasan data", "Records overview"); ?></p>
                <h2><?php echo teks("Daftar Mahasiswa", "Student Directory"); ?></h2>
                <p class="subtitle">
                    <?php echo teks("Telusuri, perbarui, atau tambahkan data akademik", "Search, update, or add academic records"); ?>
                </p>
            </div>
            <a class="button button-primary" href="tambah.php">+
                <?php echo teks("Tambah Mahasiswa", "Add Student"); ?></a>
        </section>

        <div class="toolbar">
            <div class="record-count">
                <strong><?php echo count($data); ?></strong>
                <?php echo teks("data ditampilkan", "records shown"); ?>
                <?php if ($kata != "") { ?>
                    <span> · <?php echo teks("pencarian:", "query:"); ?> “<?php echo htmlspecialchars($kata); ?>”</span>
                <?php } ?>
            </div>
            <form method="GET" action="index.php" class="search" role="search">
                <input type="text" name="cari" value="<?php echo htmlspecialchars($kata); ?>"
                    aria-label="Cari NIM atau nama"
                    placeholder="<?php echo teks("Cari NIM atau nama", "Search ID or name"); ?>">
                <button type="submit"><?php echo teks("Cari", "Search"); ?></button>
                <?php if ($kata != "") { ?>
                    <a class="search-reset" href="index.php"><?php echo teks("Reset", "Clear"); ?></a>
                <?php } ?>
            </form>
        </div>

        <div class="table-wrap">
            <table class="student-table">
                <thead>
                    <tr>
                        <th>NIM</th>
                        <th><?php echo teks("Mahasiswa", "Student"); ?></th>
                        <th>Email</th>
                        <th><?php echo teks("Jenis Kelamin", "Gender"); ?></th>
                        <th><?php echo teks("Program Studi", "Study Program"); ?></th>
                        <th><?php echo teks("Aksi", "Actions"); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($data) > 0) { ?>
                        <?php foreach ($data as $mhs) { ?>
                            <tr>
                                <td class="nim"><?php echo htmlspecialchars($mhs["nim"]); ?></td>
                                <td><span class="cell-primary"><?php echo htmlspecialchars($mhs["nama"]); ?></span></td>
                                <td><span class="cell-secondary"><?php echo htmlspecialchars($mhs["email"]); ?></span></td>
                                <td><span class="gender-tag"><?php echo htmlspecialchars($mhs["jenis_kelamin"]); ?></span></td>
                                <td><?php echo htmlspecialchars($mhs["prodi"]); ?></td>
                                <td>
                                    <div class="actions">
                                        <a class="action-link"
                                            href="edit.php?id=<?php echo (int) $mhs["id"]; ?>"><?php echo teks("Edit", "Edit"); ?></a>
                                        <span class="muted" aria-hidden="true">/</span>
                                        <a class="action-link danger" href="hapus.php?id=<?php echo (int) $mhs["id"]; ?>"
                                            onclick="return confirm('<?php echo teks("Yakin ingin menghapus data ini?", "Delete this record?"); ?>')">
                                            <?php echo teks("Hapus", "Delete"); ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <strong><?php echo teks("Belum ada data yang cocok", "No matching records"); ?></strong>
                                    <?php echo teks("Coba gunakan kata kunci lain atau bersihkan pencarian.", "Try another query or clear the search"); ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </main>
</body>

</html>