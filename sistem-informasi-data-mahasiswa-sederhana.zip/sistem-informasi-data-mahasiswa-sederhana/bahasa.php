<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    isset($_GET['lang']) && is_string($_GET['lang'])
    && in_array($_GET['lang'], ['id', 'en'], true)
) {
    $_SESSION['bahasa'] = $_GET['lang'];
}

$kembali = isset($_GET['kembali']) && is_string($_GET['kembali'])
    ? $_GET['kembali']
    : '';

$halamanDiizinkan = ['index.php', 'tambah.php', 'login.php'];
if (in_array($kembali, $halamanDiizinkan, true)) {
    $tujuan = $kembali;
} elseif (preg_match('/^edit\.php\?id=[0-9]+$/', $kembali)) {
    $tujuan = $kembali;
} else {
    $tujuan = isset($_SESSION['username']) ? 'index.php' : 'login.php';
}

header('Location: ' . $tujuan);
exit;
?>