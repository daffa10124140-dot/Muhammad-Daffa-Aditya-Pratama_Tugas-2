# Sistem Informasi Data Mahasiswa — Luxury Minimalist

Versi revisi tampilan untuk aplikasi administrasi mahasiswa berbasis PHP dan MySQL. Perubahan berfokus pada konsistensi antarmuka; operasi data dan alur autentikasi tetap menggunakan struktur sederhana yang sudah ada

## Arah visual

- Palet warm ivory, charcoal, dan bronze redup; tidak memakai aksen biru
- Panel semi-transparan dengan blur tipis sebagai sentuhan glassmorphism
- Judul serif, teks antarmuka sans-serif, dan tabel dengan separator horizontal yang ringan
- Form responsif dan tabel dapat digulir horizontal pada layar kecil
- CSS lokal tanpa framework front-end atau font eksternal

## Menjalankan melalui XAMPP

1. Salin folder `mahasiswa_luxury_minimalist` ke direktori `htdocs`
2. Jalankan Apache dan MySQL dari XAMPP
3. Buka phpMyAdmin, lalu import `database.sql`
4. Pastikan pengaturan pada `koneksi.php` sesuai dengan server lokal. Pengaturan awal: host `localhost`, database `db_mahasiswa`, user `root`, password kosong
5. Buka `http://localhost/mahasiswa_luxury_minimalist/login.php`

Akun demo yang disediakan seed database: username `admin`, password `admin123`

## Berkas utama

| Berkas | Fungsi |
|---|---|
| `login.php`, `logout.php` | Login admin dan terminasi session |
| `index.php` | Daftar, pencarian, dan akses operasi data |
| `tambah.php`, `edit.php`, `hapus.php` | Operasi CRUD mahasiswa |
| `fungsi.php` | Pemeriksaan session dan teks bahasa |
| `bahasa.php` | Menyimpan pilihan bahasa |
| `koneksi.php` | Koneksi PDO ke MySQL |
| `style.css` | Sistem visual dan layout responsif |
| `database.sql` | Pembuatan tabel dan data contoh |

## Catatan pengujian

Semua berkas PHP pada paket ini sudah lolos `php -l` untuk validasi sintaks. Interaksi CRUD belum diuji end-to-end di lingkungan pembuatan karena driver PDO MySQL dan server MySQL tidak tersedia di sana, jalankan checklist pada laporan setelah proyek diimpor ke XAMPP

Untuk penggunaan di luar demonstrasi kelas, disarankan memindahkan penghapusan ke `POST` dengan token CSRF, membatasi alamat redirect di `bahasa.php`, dan mengelola kredensial database melalui konfigurasi lingkungan
