<?php
session_start();
require "koneksi.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    if ($username == "" || $password == "") {
        $error = "Username dan password wajib diisi";
    } else {
        $sql = $koneksi->prepare("SELECT * FROM users WHERE username = ?");
        $sql->execute([$username]);
        $user = $sql->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user["password"])) {
            session_regenerate_id(true);
            $_SESSION["username"] = $user["username"];
            if (!isset($_SESSION["bahasa"])) {
                $_SESSION["bahasa"] = "id";
            }
            header("Location: index.php");
            exit;
        } else {
            $error = "Username atau password salah";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f1efe8">
    <title>Login — Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="login-page">
    <main class="container small login-panel">
        <div class="login-mark"><span class="brand-mark" aria-hidden="true">M</span></div>
        <div class="form-intro">
            <p class="eyebrow">Student records / Private access</p>
            <h1>Portal Data Mahasiswa</h1>
            <p class="subtitle">Masuk untuk melanjutkan ke ruang administrasi data mahasiswa</p>
        </div>
        <?php if ($error != "") { ?>
            <p class="error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php } ?>
        <form method="POST" action="login.php" class="form-layout login-form">
            <div class="field">
                <label for="username">Username</label>
                <input id="username" type="text" name="username" autocomplete="username" required>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" autocomplete="current-password" required>
            </div>
            <button type="submit">Masuk ke aplikasi <span aria-hidden="true">↗</span></button>
        </form>
        <p class="hint">Data Login : user:admin pass:admin123</p>
    </main>
</body>

</html>