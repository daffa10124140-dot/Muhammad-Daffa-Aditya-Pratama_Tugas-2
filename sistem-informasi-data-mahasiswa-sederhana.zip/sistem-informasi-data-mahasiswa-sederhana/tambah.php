<?php
require "fungsi.php";
require "koneksi.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nim = trim($_POST["nim"]);
    $nama = trim($_POST["nama"]);
    $email = trim($_POST["email"]);
    $jenis_kelamin = isset($_POST["jenis_kelamin"]) ? $_POST["jenis_kelamin"] : "";
    $prodi = trim($_POST["prodi"]);

    if ($nim == "" || $nama == "" || $email == "" || $jenis_kelamin == "" || $prodi == "") {
        $error = "Semua kolom wajib diisi";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid";
    } else {
        try {
            $sql = $koneksi->prepare(
                "INSERT INTO mahasiswa (nim, nama, email, jenis_kelamin, prodi) VALUES (?, ?, ?, ?, ?)"
            );
            $sql->execute([$nim, $nama, $email, $jenis_kelamin, $prodi]);
            header("Location: index.php");
            exit;
        } catch (PDOException $e) {
            $error = "Data gagal disimpan. Pastikan NIM belum digunakan";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f1efe8">
    <title>Tambah Mahasiswa — Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <main class="container form-panel">
        <div class="form-topline">
            <div class="brand-lockup">
                <span class="brand-mark" aria-hidden="true">M</span>
                <div>
                    <p class="eyebrow">Student records</p>
                    <p class="subtitle">Administrasi data</p>
                </div>
            </div>
            <a class="back-link" href="index.php">← Kembali ke daftar</a>
        </div>
        <div class="form-intro">
            <p class="eyebrow">Entri baru</p>
            <h1>Tambah Mahasiswa</h1>
            <p class="subtitle">Lengkapi informasi dasar berikut. Kolom bertanda wajib diisi sebelum data disimpan</p>
        </div>
        <?php if ($error != "") { ?>
            <p class="error" role="alert"><?php echo htmlspecialchars($error); ?></p>
        <?php } ?>
        <form method="POST" action="tambah.php" class="form-layout">
            <div class="form-grid">
                <div class="field">
                    <label for="nim">NIM</label>
                    <input id="nim" type="text" name="nim" required
                        value="<?php echo isset($nim) ? htmlspecialchars($nim) : ''; ?>">
                </div>
                <div class="field">
                    <label for="nama">Nama Lengkap</label>
                    <input id="nama" type="text" name="nama" required
                        value="<?php echo isset($nama) ? htmlspecialchars($nama) : ''; ?>">
                </div>
                <div class="field full">
                    <label for="email">Email</label>
                    <input id="email" type="email" name="email" required
                        value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                </div>
                <div class="field">
                    <label for="jenis_kelamin">Jenis Kelamin</label>
                    <select id="jenis_kelamin" name="jenis_kelamin" required>
                        <option value="">Pilih jenis kelamin</option>
                        <option value="Laki-laki" <?php echo (isset($jenis_kelamin) && $jenis_kelamin == "Laki-laki") ? "selected" : ""; ?>>Laki-laki</option>
                        <option value="Perempuan" <?php echo (isset($jenis_kelamin) && $jenis_kelamin == "Perempuan") ? "selected" : ""; ?>>Perempuan</option>
                    </select>
                </div>
                <div class="field">
                    <label for="prodi">Program Studi</label>
                    <select id="prodi" name="prodi" required>
                        <option value="">Pilih program studi</option>
                        <option value="Teknik Informatika" <?php echo (isset($prodi) && $prodi == "Teknik Informatika") ? "selected" : ""; ?>>Teknik Informatika</option>
                        <option value="Sistem Informasi" <?php echo (isset($prodi) && $prodi == "Sistem Informasi") ? "selected" : ""; ?>>Sistem Informasi</option>
                        <option value="Manajemen Informatika" <?php echo (isset($prodi) && $prodi == "Manajemen Informatika") ? "selected" : ""; ?>>Manajemen Informatika</option>
                    </select>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit">Simpan data</button>
                <a class="cancel-link" href="index.php">Batalkan</a>
            </div>
        </form>
    </main>
</body>

</html>